create table temp_test_table (
	personID int IDENTITY(1,1) not null primary key,
	name nvarchar(100) not null
);