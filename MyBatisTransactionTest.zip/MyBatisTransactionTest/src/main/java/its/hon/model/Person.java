package its.hon.model;

import lombok.Data;

/**
 * Class to model a person in the Honorary management system
 *
 * @author rbb1a, Created 30 Nov 2018
 */

@Data
public class Person
{
    // **** Constants **** //

    // **** Variables **** //

    private Long personID;
    private String name;
    
    // **** Constructors **** //
    
    // **** Getters and Setters **** //

    // getters and setters created through the magic of Lombok's @Data annotation

    // **** Other Public Methods **** //
    
    // **** Static methods **** //

    // **** Private methods **** //
    
} // end class Person
