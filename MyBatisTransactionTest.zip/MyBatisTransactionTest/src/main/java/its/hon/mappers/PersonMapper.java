package its.hon.mappers;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;

import its.hon.model.Person;

/**
 * Java interface for personmapper.xml
 *
 * @author rbb1a, Created 25 Apr 2019
 */

@Mapper
public interface PersonMapper
{
    
    List<Person> findAllPeople();
    
    void insertPerson(Person person);
    
    
} // end interface PersonMapper
