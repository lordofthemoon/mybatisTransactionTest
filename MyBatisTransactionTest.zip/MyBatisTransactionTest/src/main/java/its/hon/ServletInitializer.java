package its.hon;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.web.servlet.support.SpringBootServletInitializer;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.transaction.annotation.EnableTransactionManagement;


/**
 * In Servlet 3.x container environment + Spring container will detect and loads
 * the Initializer classes automatically.
 * 
 * We make this the entry point for our Spring Boot application as well
 * 
 * @author rbb1a, created 2018-11-28
 *
 */

@SpringBootApplication
@EnableTransactionManagement(proxyTargetClass=true)
@ComponentScan("its.hon")
public class ServletInitializer extends SpringBootServletInitializer
{

	@Override
	protected SpringApplicationBuilder configure(SpringApplicationBuilder builder) 
	{
        Map<String, Object> props = new HashMap<>();
        // honorary.properties will be the name of the application properties file
        props.put("spring.config.name", "honorary");
        builder.properties(props);

		return builder.sources(ServletInitializer.class);
	} // end method configure()

	@Override
	public void onStartup(ServletContext servletContext) throws ServletException
	{
	    super.onStartup(servletContext);
	    servletContext.setInitParameter("ServiceId", "HONORARY/APPLCTN");
	} // end method onStartup()

    // required to build the application through maven, even though this is a web application
	// (otherwise the 'repackage' goal fails)
    public static void main(String[] args) 
    {
        SpringApplication.run(ServletInitializer.class, args);
    }
	
} // end class ServletInitializer
