package its.hon.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import its.hon.TransactionDebugUtils;
import its.hon.mappers.PersonMapper;
import its.hon.model.Person;


/**
 *
 *
 * @author rbb1a, Created 8 Oct 2019
 */

@Service
public class DataMigrationProcessor
{
    // **** Constants **** //

    // **** Variables **** //

    
    private final Logger logger= LoggerFactory.getLogger(DataMigrationProcessor.class);

    @Autowired private PersonMapper mapper;
    // **** Constructors **** //

    // **** Getters and Setters **** //

    // **** Other Public Methods **** //

    @Transactional 
    public void test()
    {
        logger.debug("test::entering");
        TransactionDebugUtils.transactionRequired("DataMigrationProcessor.test");

        Person p= new Person();
        p.setName("Foo Bar");
        
        mapper.insertPerson(p);
//        personService.savePerson(p, null);
//        TransactionAspectSupport.currentTransactionStatus().setRollbackOnly();
        throw new RuntimeException();
//        logger.debug("test::exiting");
    }
    
    // **** Static methods **** //

    // **** Private methods **** //

        
}

