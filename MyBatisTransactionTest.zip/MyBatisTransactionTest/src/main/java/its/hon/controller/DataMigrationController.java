package its.hon.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import its.hon.service.DataMigrationProcessor;

/**
 * Controller for data migration out of the HR system
 *
 * @author rbb1a, Created 1 Oct 2019
 */

@Controller
public class DataMigrationController
{
    // **** Constants **** //

    // **** Variables **** //
    
    private final Logger logger= LoggerFactory.getLogger(DataMigrationController.class);
    
    @Autowired
    private DataMigrationProcessor dmService;

    // **** Constructors **** //
    
    // **** Getters and Setters **** //

    public void setDmService(DataMigrationProcessor dmService) {this.dmService= dmService;}
    
    // **** Other Public Methods **** //

    
    
    @GetMapping("/test")
    public String test()
    {
        dmService.test();
        return "index";
    }
    
    // **** Static methods **** //

    // **** Private methods **** //
    
} // end class DataMigrationController
